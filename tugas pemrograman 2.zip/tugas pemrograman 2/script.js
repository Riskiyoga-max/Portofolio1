const daftar = document.getElementById("daftarTugas");

for(let i=1;i<=19;i++){

daftar.innerHTML += `

<div class="card">

<h3>Pertemuan ${i}</h3>

<p>Tugas Pertemuan ${i}</p>

<button onclick="lihat(${i})">

Lihat

</button>

</div>

`;

}

function lihat(no){

document.getElementById("hasil").src="tugas/p"+no+".html";
 "tugas/p" + no + ".html";
}