function login(){

let username=document.getElementById("username").value;

let password=document.getElementById("password").value;

if(username=="admin" && password=="12345"){

document.getElementById("hasil").innerHTML=
"<span style='color:#00ff99'>✔ Login Berhasil</span>";

}
else{

document.getElementById("hasil").innerHTML=
"<span style='color:#ff4444'>✖ Username atau Password Salah</span>";

}

}